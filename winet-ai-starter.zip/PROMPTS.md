# PROMPTS — Construire WiNet avec l'IA
(Architecte API, Codegen Serveur, Database, Mikhmon Proxy, Mobile, Portails, Sécurité/Tests, DevOps)
