# WiNet — AI-First Starter (MVP)
Ce dépôt est une **ossature** pour construire WiNet **entièrement avec l'IA** (Copilot/Cursor/ChatGPT).
Voir `PROMPTS.md`, `docs/openapi.yml`, `backend/api/db/schema.sql`, `routeros/scripts/bootstrap_template.rsc`.
